package carla.senaitrabalho;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import javax.microedition.khronos.egl.EGLDisplay;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText editTextTexto = findViewById(R.id.editText1);
        EditText editTextTexto2 = findViewById(R.id.editText2);
        Button btnMostrar = findViewById(R.id.btnmostrar);
        Button btmlimpar = findViewById(R.id.btnlimpar);

        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText1 = findViewById(R.id.editText1);
                EditText editText2 = findViewById(R.id.editText2);

                String editText3 = editText1.getText().toString() + editText2.getText().toString();
                Toast.makeText(MainActivity.this, editText3, Toast.LENGTH_SHORT).show();
            }

        });


        btmlimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText1 = findViewById(R.id.editText1);
                editText1.setText("");
                EditText editText2 = findViewById(R.id.editText2);
                editText2.setText("");
            }
        });
    }}